import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class PasswordCracker {
    private static final String ZIP_FILE_PATH_1 = "protected3.zip";
    private static final String ZIP_FILE_PATH_2 = "protected5.zip";
    private static final int NUM_THREADS = 4; // Number of threads used for multi-threaded cracking
    private static final Object lock = new Object(); // Lock for synchronization
    private static volatile String foundPassword = null; // Volatile variable to store the found password

    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();

        // Crack password for file 1
        String password1 = crackPassword(3, ZIP_FILE_PATH_1);
        long endTime1 = System.currentTimeMillis();
        System.out.println("Correct password for file 1: " + password1);
        System.out.println("Time taken for file 1 (ms): " + (endTime1 - startTime));

        // Crack password for file 2
        String password2 = crackPassword(NUM_THREADS, ZIP_FILE_PATH_2);
        long endTime2 = System.currentTimeMillis();
        System.out.println("Correct password for file 2: " + password2);
        System.out.println("Time taken for file 2 (ms): " + (endTime2 - endTime1));
    }

    // Method to initiate password cracking based on length and zip file path
    public static String crackPassword(int length, String zipFilePath) {
        if (length == 3) {
            return crackPasswordSingleThreaded(length, zipFilePath);
        } else {
            return crackPasswordMultiThreaded(length, zipFilePath);
        }
    }

    // Single-threaded password cracking method
    public static String crackPasswordSingleThreaded(int length, String zipFilePath) {
        StringBuilder password = new StringBuilder();
        char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();

        for (char c1 : alphabet) {
            for (char c2 : alphabet) {
                for (char c3 : alphabet) {
                    password.setLength(0);
                    password.append(c1).append(c2).append(c3);
                    if (isValidPassword(password.toString(), zipFilePath)) {
                        return password.toString();
                    }
                }
            }
        }
        return null;
    }

    // Multi-threaded password cracking method
    public static String crackPasswordMultiThreaded(int numThreads, String zipFilePath) {
        ExecutorService executorService = Executors.newFixedThreadPool(numThreads);

        try {
            for (int i = 0; i < numThreads; i++) {
                executorService.submit(new PasswordFinder(zipFilePath));
            }

            executorService.shutdown();
            executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return PasswordCracker.foundPassword;
    }

    // Method to check if a password is valid for a given zip file
    public static boolean isValidPassword(String password, String zipFilePath) {
        try {
            // Create a unique directory for each thread
            Path contentsDir = Paths.get("contents-" + Thread.currentThread().getId());
            Files.createDirectories(contentsDir);

            ZipFile zipFile = new ZipFile(zipFilePath);
            zipFile.setPassword(password);
            zipFile.extractAll(contentsDir.toString());

            // Check if the zip file is valid
            if (zipFile.isValidZipFile()) {
                synchronized (lock) {
                    if (foundPassword == null) {
                        foundPassword = password;
                    }
                }
                return true;
            } else {
                // Delete the directory and its contents if the password is invalid
                Files.walk(contentsDir)
                        .sorted(java.util.Comparator.reverseOrder())
                        .map(Path::toFile)
                        .forEach(File::delete);

                Files.deleteIfExists(contentsDir);
            }
        } catch (ZipException | IOException e) {
            return false;
        }
        return false;
    }

    // Runnable class for multi-threaded password cracking
    public static class PasswordFinder implements Runnable {
        private final String zipFilePath;

        public PasswordFinder(String zipFilePath) {
            this.zipFilePath = zipFilePath;
        }

        @Override
        public void run() {
            try {
                char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();

                for (char c1 : alphabet) {
                    for (char c2 : alphabet) {
                        for (char c3 : alphabet) {
                            for (char c4 : alphabet) {
                                for (char c5 : alphabet) {
                                    String password = "" + c1 + c2 + c3 + c4 + c5;
                                    if (isValidPassword(password, zipFilePath)) {
                                        synchronized (lock) {
                                            if (foundPassword == null) {
                                                foundPassword = password;
                                            }
                                        }
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}